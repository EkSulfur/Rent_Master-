from django.apps import AppConfig


class RentingLogsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'renting_logs'
